package fiji.tool;

public interface ToolToggleListener {
	public void toolToggled(boolean enabled);
}